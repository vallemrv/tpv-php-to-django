# @Author: Manuel Rodriguez <valle>
# @Date:   11-Sep-2017
# @Email:  valle.mrv@gmail.com
# @Last modified by:   valle
# @Last modified time: 16-Mar-2018
# @License: Apache license vesion 2.0



from .arqueos import *
from .pedidos import *
from valle_libs.config import config
from valle_libs.valleorm.qson import QSonSender, QSon as _QSon

class QSon(_QSon):
    pass

class VentasSender(QSonSender):
     db_name = "ventas"
     url = config.URL_SERVER+"/simpleapi/"
