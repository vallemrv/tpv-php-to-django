# @Author: Manuel Rodriguez <valle>
# @Date:   01-Mar-2018
# @Email:  valle.mrv@gmail.com
# @Last modified by:   valle
# @Last modified time: 17-Mar-2018
# @License: Apache license vesion 2.0


#URL_SERVER = "http://btres.elbrasilia.com"
URL_SERVER = "http://localhost:8000"
IP_PRINTER_CAJA = "192.168.1.5"
TOKEN_API = "4td-c40a6792be0f208a284f"
TOKEN_USER = 2
PORT_SERVICE = 3000
PORT_TPV = 3001
